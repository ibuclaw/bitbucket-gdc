+--------------------------------------+
| Translation of the Win32 API headers |
+--------------------------------------+

This is a project to create a well-crafted translation of the Windows 32-bit API headers in the D programming language.

The project started off as an improvement of Y. Tomino's translation, but is now a derivative of the public domain MinGW Windows headers.

The official project page is at

http://www.dsource.org/projects/bindings/wiki/WindowsApi

If you wish to contribute to this project, please assign modules to yourself at that site, and refer to the translation instructions.

Email me with comments/suggestions/bug reports: smjg@iname.com
